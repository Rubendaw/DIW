<?php
$servidor = "localhost"; 
$username = "daw";
$password = "daw";
$basedatos = "Heroes";


$conn = mysqli_connect($servidor, $username, $password, $basedatos);

?>