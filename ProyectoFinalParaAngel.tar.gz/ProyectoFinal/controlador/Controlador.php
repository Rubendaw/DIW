<?php

require_once("../Vista/head.php");
require_once("../Vista/login.php");
//require_once("../Vista/Vista.php");
//en este archivo tengo que hacer mediante require llamar a vista
require_once("../Vista/footer.php");

?>
